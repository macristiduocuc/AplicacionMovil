package com.example.deprueba.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.deprueba.data.Product
import com.example.deprueba.data.ProductDatabaseHelper

@Composable
fun ProductListScreen(context: android.content.Context, navController: NavController) {
    val dbHelper = remember { ProductDatabaseHelper(context) }
    var productos by remember { mutableStateOf(listOf<Product>()) }

    LaunchedEffect(Unit) {
        productos = dbHelper.obtenerProductos()
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row {
            Text("Lista de productos", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            Button(onClick = { navController.navigate("agregarProducto") }) {
                Text("Agregar")
            }
        }
        Spacer(Modifier.height(8.dp))

        LazyColumn {
            items(productos) { producto ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(8.dp)) {
                        Text(producto.name, style = MaterialTheme.typography.titleMedium)
                        Text("Precio: $${producto.price}")
                        Text("Stock: ${producto.stock}")
                        Text("Categoría: ${producto.category}")
                    }
                }
            }
        }
    }
}

