package com.example.deprueba.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.deprueba.data.Product
import com.example.deprueba.data.ProductDatabaseHelper

@Composable
fun AddProductScreen(context: android.content.Context, navController: NavController) {
    val dbHelper = remember { ProductDatabaseHelper(context) }

    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Agregar nuevo producto", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nombre") })
        OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Descripción") })
        OutlinedTextField(value = price, onValueChange = { price = it }, label = { Text("Precio") })
        OutlinedTextField(value = stock, onValueChange = { stock = it }, label = { Text("Stock") })
        OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Categoría") })

        Spacer(Modifier.height(16.dp))

        Button(onClick = {
            if (name.isNotBlank()) {
                dbHelper.insertarProducto(
                    Product(
                        name = name,
                        description = desc,
                        price = price.toDoubleOrNull() ?: 0.0,
                        stock = stock.toIntOrNull() ?: 0,
                        category = category
                    )
                )
                // al volver al listado, la pantalla de lista en su LaunchedEffect volverá a cargar al recomponer si lo configuras así
                navController.popBackStack()
            }
        }) {
            Text("Guardar producto")
        }
    }
}
