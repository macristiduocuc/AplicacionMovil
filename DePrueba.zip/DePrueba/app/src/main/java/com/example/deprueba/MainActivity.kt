package com.example.deprueba

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.deprueba.ui.AddProductScreen
import com.example.deprueba.ui.ProductListScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TiendaApp()
        }
    }
}

@Composable
fun TiendaApp() {
    val navController = rememberNavController()
    Scaffold(
        topBar = { TopAppBar(title = { Text("Mi Tienda") }) }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "productos",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("productos") {
                ProductListScreen(
                    context = LocalContext.current,
                    navController = navController
                )
            }
            composable("agregarProducto") {
                AddProductScreen(
                    context = LocalContext.current,
                    navController = navController
                )
            }
        }
    }
}
