package com.example.deprueba

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class ProductDatabaseHelper(context: Context)
    : SQLiteOpenHelper(context, "productos.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE productos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT,
                descripcion TEXT,
                precio REAL,
                stock INTEGER,
                categoria TEXT
            )
        """.trimIndent())

        // Productos iniciales
        db.execSQL("INSERT INTO productos (nombre, descripcion, precio, stock, categoria) VALUES ('Camiseta', 'Camiseta algodón', 9990, 15, 'Ropa')")
        db.execSQL("INSERT INTO productos (nombre, descripcion, precio, stock, categoria) VALUES ('Taza', 'Taza de cerámica', 4990, 20, 'Accesorios')")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS productos")
        onCreate(db)
    }

    fun insertarProducto(product: Product) {
        writableDatabase.use { db ->
            val values = ContentValues().apply {
                put("nombre", product.name)
                put("descripcion", product.description)
                put("precio", product.price)
                put("stock", product.stock)
                put("categoria", product.category)
            }
            db.insert("productos", null, values)
        }
    }

    fun obtenerProductos(): List<Product> {
        val lista = mutableListOf<Product>()
        readableDatabase.use { db ->
            val cursor = db.rawQuery("SELECT id, nombre, descripcion, precio, stock, categoria FROM productos", null)
            cursor.use {
                if (it.moveToFirst()) {
                    do {
                        lista.add(
                            Product(
                                id = it.getInt(0),
                                name = it.getString(1),
                                description = it.getString(2),
                                price = it.getDouble(3),
                                stock = it.getInt(4),
                                category = it.getString(5)
                            )
                        )
                    } while (it.moveToNext())
                }
            }
        }
        return lista
    }
}
