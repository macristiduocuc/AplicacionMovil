package com.example.huertabeja.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.huertabeja.screens.*

@Composable
fun AppNavigation() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = AppScreens.HomeScreen.route // Empezamos en la pantalla de inicio
    ) {
        composable(route = AppScreens.HomeScreen.route) {
            HomeScreen(navController)
        }
        composable(route = AppScreens.LoginScreen.route) {
            LoginScreen(navController)
        }
        composable(route = AppScreens.ProductsScreen.route) {
            ProductsScreen(navController)
        }
        composable(route = AppScreens.AddProductScreen.route) {
            AddProductScreen(navController)
        }
        composable(route = AppScreens.CartScreen.route) {
            CartScreen(navController)
        }
        composable(route = AppScreens.AboutScreen.route) {
            AboutScreen(navController)
        }
    }
}